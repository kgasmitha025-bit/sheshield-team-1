﻿import React, { useState } from 'react';
import {
  MessageSquareWarning,
  ShieldAlert,
  AlertOctagon,
  CheckCircle2,
  AlertTriangle,
  Send,
  Sparkles,
  BookmarkPlus,
  FileCheck,
  Scale,
  Copy,
  Check,
  Loader2,
  Info,
} from 'lucide-react';
import { AnalysisResult, EvidenceItem, Language } from '../types';

interface MessageScannerProps {
  lang: Language;
  onAddToVault: (item: Omit<EvidenceItem, 'id' | 'timestamp'>) => void;
  onNavigateToVault: () => void;
}

export const MessageScanner: React.FC<MessageScannerProps> = ({
  lang,
  onAddToVault,
  onNavigateToVault,
}) => {
  const [inputText, setInputText] = useState<string>('');
  const [screenshotFile, setScreenshotFile] = useState<File | null>(null);
  const [screenshotPreview, setScreenshotPreview] = useState<string | null>(null);
  const [platform, setPlatform] = useState<string>('WhatsApp');
  const [senderHandle, setSenderHandle] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [isAddedToVault, setIsAddedToVault] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const sampleMessages = [
    {
      labelEn: 'Morph Extortion Threat',
      labelTa: 'à®®à®¾à®°à¯à®ªà®¿à®™à¯ à®®à®¿à®°à®Ÿà¯à®Ÿà®²à¯ à®šà¯†à®¯à¯à®¤à®¿',
      platform: 'WhatsApp / Telegram',
      text:
        lang === 'ta'
          ? 'à®Žà®©à¯à®©à®¿à®Ÿà®®à¯ à®‰à®©à¯à®©à¯à®Ÿà¯ˆà®¯ à®®à®¾à®°à¯à®ªà®¿à®™à¯ à®šà¯†à®¯à¯à®¯à®ªà¯à®ªà®Ÿà¯à®Ÿ à®¨à®¿à®°à¯à®µà®¾à®£ à®ªà¯à®•à¯ˆà®ªà¯à®ªà®Ÿà®™à¯à®•à®³à¯ à®®à®±à¯à®±à¯à®®à¯ à®µà¯€à®Ÿà®¿à®¯à¯‹à®•à¯à®•à®³à¯ à®‰à®³à¯à®³à®©. à®‰à®Ÿà®©à®Ÿà®¿à®¯à®¾à®• 50,000 à®°à¯‚à®ªà®¾à®¯à¯ à®…à®©à¯à®ªà¯à®ªà®µà®¿à®²à¯à®²à¯ˆ à®Žà®©à¯à®±à®¾à®²à¯, à®‰à®©à®¤à¯ à®•à¯à®Ÿà¯à®®à¯à®ªà®¤à¯à®¤à®¿à®©à®°à¯à®•à¯à®•à¯à®®à¯ à®•à®²à¯à®²à¯‚à®°à®¿ à®•à¯à®´à¯à®µà®¿à®±à¯à®•à¯à®®à¯ à®…à®©à¯à®ªà¯à®ªà®¿à®µà®¿à®Ÿà¯à®µà¯‡à®©à¯.'
          : 'I have your morphed photos and video. If you do not transfer â‚¹50,000 to my UPI within 1 hour, I will send them to all your Instagram followers and your family members.',
    },
    {
      labelEn: 'Cyber Stalking / Intimidation',
      labelTa: 'à®ªà®¿à®©à¯à®¤à¯Šà®Ÿà®°à¯à®¤à®²à¯ & à®…à®šà¯à®šà¯à®±à¯à®¤à¯à®¤à®²à¯',
      platform: 'Instagram DM',
      text:
        lang === 'ta'
          ? 'à®‡à®©à¯à®±à¯ à®®à®¾à®²à¯ˆ 6:30 à®®à®£à®¿à®•à¯à®•à¯ à®¨à¯€ à®…à®²à¯à®µà®²à®•à®¤à¯à®¤à¯ˆ à®µà®¿à®Ÿà¯à®Ÿà¯ à®•à®¿à®³à®®à¯à®ªà®¿à®¯à®¤à¯ˆ à®ªà®¾à®°à¯à®¤à¯à®¤à¯‡à®©à¯. à®¨à¯€ à®¨à¯€à®² à®¨à®¿à®± à®šà¯à®Ÿà®¿à®¤à®¾à®°à¯ à®…à®£à®¿à®¨à¯à®¤à®¿à®°à¯à®¨à¯à®¤à®¾à®¯à¯. à®Žà®©à¯ à®®à¯†à®šà¯‡à®œà¯à®•à®³à¯à®•à¯à®•à¯ à®ªà®¤à®¿à®²à¯ à®šà¯Šà®²à¯à®²à®µà®¿à®²à¯à®²à¯ˆ à®Žà®©à¯à®±à®¾à®²à¯ à®‰à®©à¯ à®µà¯€à®Ÿà¯à®Ÿà®¿à®±à¯à®•à¯ à®µà®°à¯à®µà¯‡à®©à¯.'
          : 'I saw you leave your office today at 6:30 PM wearing that blue suit. Why did you block my number? You cannot escape me, I know exactly which metro station you use.',
    },
    {
      labelEn: 'Benign / Normal Message',
      labelTa: 'à®šà®¾à®¤à®¾à®°à®£ à®¨à®Ÿà¯à®ªà¯ à®šà¯†à®¯à¯à®¤à®¿',
      platform: 'Email / Chat',
      text:
        lang === 'ta'
          ? 'à®µà®£à®•à¯à®•à®®à¯, à®¨à®¾à®³à¯ˆ à®•à®¾à®²à¯ˆ à®¨à®Ÿà¯ˆà®ªà¯†à®± à®‰à®³à¯à®³ à®®à¯€à®Ÿà¯à®Ÿà®¿à®™à¯à®•à®¿à®±à¯à®•à®¾à®© à®ªà¯ˆà®²à¯à®•à®³à¯ˆ à®®à®¿à®©à¯à®©à®žà¯à®šà®²à®¿à®²à¯ à®…à®©à¯à®ªà¯à®ª à®®à¯à®Ÿà®¿à®¯à¯à®®à®¾? à®¨à®©à¯à®±à®¿.'
          : 'Hi! Could you please share the notes from todayâ€™s seminar when you get a chance? No rush, thank you!',
    },
  ];

  const handleRunAnalysis = async (textToScan: string) => {
  if (!screenshotFile) {
  setErrorMsg(
    lang === 'ta'
      ? 'à®®à¯à®¤à®²à®¿à®²à¯ à®šà¯†à®¯à¯à®¤à®¿ à®¸à¯à®•à®¿à®°à¯€à®©à¯à®·à®¾à®Ÿà¯à®Ÿà¯ˆ à®ªà®¤à®¿à®µà¯‡à®±à¯à®±à®µà¯à®®à¯'
      : 'Please upload a message screenshot first'
  );
  return;
}

    setErrorMsg(null);
    setIsAnalyzing(true);
    setIsAddedToVault(false);
    setResult(null);

    try {
     const formData = new FormData();

formData.append('screenshot', screenshotFile);
formData.append('lang', lang);

const response = await fetch('/api/analyze-message', {
  method: 'POST',
  body: formData,
});

      const data = await response.json();

      if (data.success) {
        setResult({
          success: true,
          isDemoAnalysis: data.isDemoAnalysis,
          riskLevel: data.riskLevel,
          riskScore: data.riskScore,
          category: data.category,
          summaryTitle: data.summaryTitle,
          summaryDesc: data.summaryDesc,
          reasons: data.reasons,
          timestamp: new Date().toISOString(),
        });
      } else {
        // Dynamic client-side legal evaluator fallback
        const lower = textToScan.toLowerCase();
        const hasThreat =
          lower.includes('photo') ||
          lower.includes('morph') ||
          lower.includes('money') ||
          lower.includes('upi') ||
          lower.includes('transfer') ||
          lower.includes('video') ||
          lower.includes('rupees') ||
          lower.includes('à®•à¯à®Ÿà¯à®®à¯à®ª') ||
          lower.includes('à®®à®¾à®°à¯à®ªà®¿à®™à¯') ||
          lower.includes('à®ªà®£à®®à¯');

        const hasStalk =
          lower.includes('saw you') ||
          lower.includes('watching') ||
          lower.includes('know where') ||
          lower.includes('follow') ||
          lower.includes('à®ªà®¾à®°à¯à®¤à¯à®¤à¯‡à®©à¯') ||
          lower.includes('à®µà¯€à®Ÿà¯à®Ÿà®¿à®±à¯à®•à¯');

        const isHigh = hasThreat;
        const isMed = hasStalk && !isHigh;
        const score = isHigh ? 88 : isMed ? 52 : 12;
        const level = isHigh ? 'high' : isMed ? 'medium' : 'low';

        setResult({
          success: true,
          isDemoAnalysis: true,
          riskLevel: level,
          riskScore: score,
          category: isHigh
            ? (lang === 'ta' ? 'à®®à®¾à®°à¯à®ªà®¿à®™à¯ & à®ªà®£à®®à¯ à®ªà®±à®¿à®¤à¯à®¤à®²à¯ à®®à®¿à®°à®Ÿà¯à®Ÿà®²à¯' : 'Non-Consensual Image Threat & Extortion')
            : isMed
            ? (lang === 'ta' ? 'à®šà¯ˆà®ªà®°à¯ à®ªà®¿à®©à¯à®¤à¯Šà®Ÿà®°à¯à®¤à®²à¯ & à®•à®£à¯à®•à®¾à®£à®¿à®ªà¯à®ªà¯' : 'Cyber Stalking & Unwanted Monitoring')
            : (lang === 'ta' ? 'à®ªà®¾à®¤à¯à®•à®¾à®ªà¯à®ªà®¾à®© à®‰à®°à¯ˆà®¯à®¾à®Ÿà®²à¯' : 'Benign Safe Communication'),
          summaryTitle: isHigh
            ? (lang === 'ta' ? 'âš  à®¤à¯€à®µà®¿à®° à®…à®šà¯à®šà¯à®±à¯à®¤à¯à®¤à®²à¯ à®•à®£à¯à®Ÿà®±à®¿à®¯à®ªà¯à®ªà®Ÿà¯à®Ÿà®¤à¯' : 'âš  Severe Harassment / Extortion Threat')
            : isMed
            ? (lang === 'ta' ? 'à®¨à®Ÿà¯à®¤à¯à®¤à®° à®†à®ªà®¤à¯à®¤à¯ (à®ªà®¿à®©à¯à®¤à¯Šà®Ÿà®°à¯à®¤à®²à¯)' : 'Medium Risk (Intrusive Stalking)')
            : (lang === 'ta' ? 'à®•à¯à®±à¯ˆà®¨à¯à®¤ à®†à®ªà®¤à¯à®¤à¯ (à®ªà®¾à®¤à¯à®•à®¾à®ªà¯à®ªà®¾à®©à®¤à¯)' : 'Low Risk / Safe Communication'),
          summaryDesc: isHigh
            ? (lang === 'ta'
                ? 'à®¤à®©à®¿à®ªà¯à®ªà®Ÿà¯à®Ÿ à®ªà®Ÿà®™à¯à®•à®³à¯ à®…à®²à¯à®²à®¤à¯ à®®à®¾à®°à¯à®ªà®¿à®™à¯ à®…à®šà¯à®šà¯à®±à¯à®¤à¯à®¤à®²à¯ à®®à¯‚à®²à®®à¯ à®ªà®£à®®à¯ à®ªà®±à®¿à®•à¯à®•à¯à®®à¯ à®®à¯à®¯à®±à¯à®šà®¿ (88% à®†à®ªà®¤à¯à®¤à¯). à®‡à®¤à¯ à®•à®Ÿà¯à®®à¯ˆà®¯à®¾à®© à®•à®¿à®°à®¿à®®à®¿à®©à®²à¯ à®•à¯à®±à¯à®±à®®à®¾à®•à¯à®®à¯.'
                : 'Direct extortion using morphed media or private content. This constitutes a severe cognizable offense under Indian Law (88% threat score).')
            : isMed
            ? (lang === 'ta'
                ? 'à®¤à®©à®¿à®¨à®ªà®°à¯ à®¨à®Ÿà®®à®¾à®Ÿà¯à®Ÿà®¤à¯à®¤à¯ˆ à®•à®£à¯à®•à®¾à®£à®¿à®¤à¯à®¤à¯ à®…à®šà¯à®šà¯à®±à¯à®¤à¯à®¤à¯à®®à¯ à®¤à®©à¯à®®à¯ˆ à®•à¯Šà®£à¯à®Ÿà¯à®³à¯à®³à®¤à¯.'
                : 'Observed intrusive tracking and intimidation patterns indicative of cyber stalking.')
            : (lang === 'ta'
                ? 'à®‡à®¤à®¿à®²à¯ à®Žà®¨à¯à®¤à®µà®¿à®¤ à®…à®šà¯à®šà¯à®±à¯à®¤à¯à®¤à®²à¯‹ à®…à®²à¯à®²à®¤à¯ à®®à®¿à®°à®Ÿà¯à®Ÿà®²à¯‹ à®‡à®²à¯à®²à¯ˆ.'
                : 'No criminal intimidation, stalking, or extortion indicators detected in this text.'),
          reasons: isHigh
            ? (lang === 'ta'
                ? [
                    'à®ªà®Ÿà®™à¯à®•à®³à¯ˆ à®ªà¯Šà®¤à¯à®µà¯†à®³à®¿à®¯à®¿à®²à¯ à®ªà®°à®ªà¯à®ªà¯à®µà®¤à®¾à®• à®®à®¿à®°à®Ÿà¯à®Ÿà®¿ à®ªà®£à®®à¯ à®ªà®±à®¿à®•à¯à®•à¯à®®à¯ à®¨à¯‹à®•à¯à®•à®®à¯',
                    'IT Act 66E à®®à®±à¯à®±à¯à®®à¯ BNS 351 (à®®à®¿à®°à®Ÿà¯à®Ÿà®²à¯) à®šà®Ÿà¯à®Ÿà®™à¯à®•à®³à®¿à®©à¯ à®•à¯€à®´à¯ à®¤à®£à¯à®Ÿà®©à¯ˆà®•à¯à®•à¯à®°à®¿à®¯à®¤à¯',
                    'à®‰à®Ÿà®©à®Ÿà®¿à®¯à®¾à®• à®šà¯ˆà®ªà®°à¯ à®•à®¿à®°à¯ˆà®®à¯ à®ªà¯‹à®²à¯€à®šà®¿à®²à¯ à®ªà¯à®•à®¾à®°à¯ à®…à®³à®¿à®•à¯à®• à®¤à®•à¯à®¤à®¿à®¯à®¾à®© à®†à®¤à®¾à®°à®®à¯'
                  ]
                : [
                    'Explicit threat to distribute non-consensual or morphed imagery',
                    'Financial blackmail demand constituting criminal extortion under BNS Sec 351',
                    'Actionable violation under Information Technology Act Sec 66E & 67A'
                  ])
            : isMed
            ? (lang === 'ta'
                ? ['à®¤à®©à®¿à®¨à®ªà®°à¯ à®‡à®°à¯à®ªà¯à®ªà®¿à®Ÿà®¤à¯à®¤à¯ˆ à®•à®£à¯à®•à®¾à®£à®¿à®¤à¯à®¤à¯ à®…à®šà¯à®šà®¤à¯à®¤à¯ˆ à®à®±à¯à®ªà®Ÿà¯à®¤à¯à®¤à¯à®®à¯ à®šà¯Šà®²à¯à®¨à®Ÿà¯ˆ']
                : ['Unwanted surveillance and tracking of physical movements violating BNS Sec 78'])
            : (lang === 'ta'
                ? ['à®µà®´à®•à¯à®•à®®à®¾à®© à®¤à®•à®µà®²à¯ à®ªà®°à®¿à®®à®¾à®±à¯à®±à®®à¯']
                : ['Standard polite and professional communication with zero coercion']),
          timestamp: new Date().toISOString(),
        });
      }
    } catch (err: any) {
      console.warn('Network error calling /api/analyze-message:', err);
      setErrorMsg(lang === 'ta' ? 'à®†à®¯à¯à®µà¯ à®ªà®¿à®´à¯ˆ à®à®±à¯à®ªà®Ÿà¯à®Ÿà®¤à¯.' : 'Analysis error. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSaveToVault = () => {
    if (!result) return;
    onAddToVault({
      type: 'text',
      title: `${platform} - ${senderHandle || (lang === 'ta' ? 'à®…à®Ÿà¯ˆà®¯à®¾à®³à®®à¯ à®¤à¯†à®°à®¿à®¯à®¾à®¤à®µà®°à¯' : 'Unknown Sender')}`,
      content: inputText.trim(),
      riskLevel: result.riskLevel,
      riskScore: result.riskScore,
      category: result.category,
      reasons: result.reasons,
      platform,
      accusedInfo: senderHandle || undefined,
      notes: lang === 'ta' ? 'SheShield à®šà®Ÿà¯à®Ÿ à®®à®±à¯à®±à¯à®®à¯ à®…à®šà¯à®šà¯à®±à¯à®¤à¯à®¤à®²à¯ à®†à®¯à¯à®µà¯' : 'SheShield Legal & Threat Classification',
    });
    setIsAddedToVault(true);
  };

  const handleCopyLegalAdvice = () => {
    if (!result) return;
    const textToCopy = `[SheShield Evidence Record]\nPlatform: ${platform}\nSender: ${senderHandle || 'Not specified'}\nRisk Level: ${result.riskLevel.toUpperCase()} (${result.riskScore}%)\nCategory: ${result.category}\nContent: "${inputText}"\nKey Findings:\n- ${result.reasons.join('\n- ')}`;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-5 md:p-6 border border-purple-100 shadow-xs">
        <div className="flex items-center gap-2 mb-1">
          <span className="w-2.5 h-2.5 rounded-full bg-rose-600 animate-ping"></span>
          <span className="text-xs font-bold text-rose-700 uppercase tracking-wider">
            {lang === 'ta' ? 'à®…à®šà¯à®šà¯à®±à¯à®¤à¯à®¤à®²à¯ & à®®à®¿à®°à®Ÿà¯à®Ÿà®²à¯ à®†à®¯à¯à®µà¯' : 'Harassment & Threat Scanner'}
          </span>
        </div>
        <h2 className="text-xl md:text-2xl font-bold text-slate-900 tracking-tight">
          {lang === 'ta' ? 'à®šà¯†à®¯à¯à®¤à®¿à®•à®³à¯ & à®…à®šà¯à®šà¯à®±à¯à®¤à¯à®¤à®²à¯à®•à®³à¯ˆ à®®à®¤à®¿à®ªà¯à®ªà¯€à®Ÿà¯ à®šà¯†à®¯à¯à®¯à¯à®™à¯à®•à®³à¯' : 'Analyze DMs, Blackmail & Cyber Stalking'}
        </h2>
        <p className="text-sm text-slate-600 mt-1 max-w-2xl">
          {lang === 'ta'
            ? 'à®µà®¾à®Ÿà¯à®¸à¯à®…à®ªà¯, à®‡à®©à¯à®¸à¯à®Ÿà®¾à®•à®¿à®°à®¾à®®à¯ à®…à®²à¯à®²à®¤à¯ à®®à®¿à®©à¯à®©à®žà¯à®šà®²à®¿à®²à¯ à®µà®°à¯à®®à¯ à®®à®¿à®°à®Ÿà¯à®Ÿà®²à¯ à®šà¯†à®¯à¯à®¤à®¿à®•à®³à¯ˆ à®‡à®™à¯à®•à¯‡ à®’à®Ÿà¯à®Ÿà®¿, à®‡à®¨à¯à®¤à®¿à®¯ à®¤à®•à®µà®²à¯ à®¤à¯Šà®´à®¿à®²à¯à®¨à¯à®Ÿà¯à®ª à®šà®Ÿà¯à®Ÿà®®à¯ à®®à®±à¯à®±à¯à®®à¯ à®•à¯à®±à¯à®±à®µà®¿à®¯à®²à¯ à®šà®Ÿà¯à®Ÿà®™à¯à®•à®³à®¿à®©à¯ à®•à¯€à®´à¯ à®…à®µà®±à¯à®±à®¿à®©à¯ à®¤à¯€à®µà®¿à®°à®¤à¯à®¤à¯ˆ à®…à®±à®¿à®¯à¯à®™à¯à®•à®³à¯.'
            : 'Paste suspicious chat messages, extortion demands, or stalking texts to evaluate criminal severity under Indian IT Act & Bharatiya Nyaya Sanhita (BNS).'}
        </p>

        {/* Sample Pills */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center gap-2">
          <span className="text-xs font-bold text-slate-500">
            {lang === 'ta' ? 'à®®à®¾à®¤à®¿à®°à®¿ à®šà¯†à®¯à¯à®¤à®¿à®•à®³à¯:' : 'Quick Test Cases:'}
          </span>
          {sampleMessages.map((sample, idx) => (
            <button
              key={idx}
              onClick={() => {
                setInputText(sample.text);
                setPlatform(sample.platform);
                handleRunAnalysis(sample.text);
              }}
              className="text-xs font-semibold px-3 py-1.5 rounded-xl bg-purple-50 text-purple-700 hover:bg-purple-100 border border-purple-200 transition-colors"
            >
              {lang === 'ta' ? sample.labelTa : sample.labelEn}
            </button>
          ))}
        </div>
      </div>

      {/* Main Analysis Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Input Textarea (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
            {/* Metadata bar */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'ta' ? 'à®¤à®³à®®à¯ / à®šà¯†à®¯à®²à®¿' : 'Platform / Origin'}
                </label>
                <select
                  value={platform}
                  onChange={(e) => setPlatform(e.target.value)}
                  className="w-full text-xs font-semibold bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-purple-400"
                >
                  <option value="WhatsApp">WhatsApp</option>
                  <option value="Instagram">Instagram DM</option>
                  <option value="Telegram">Telegram</option>
                  <option value="X (Twitter)">X / Twitter</option>
                  <option value="Facebook Messenger">Facebook Messenger</option>
                  <option value="SMS / Text">SMS / Cellular Text</option>
                  <option value="Email">Email</option>
                  <option value="Other">Other Electronic Platform</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'ta' ? 'à®…à®©à¯à®ªà¯à®ªà®¿à®¯à®µà®°à®¿à®©à¯ à®Žà®£à¯ / à®à®Ÿà®¿ (à®µà®¿à®°à¯à®ªà¯à®ªà®®à¯)' : 'Sender ID / Handle (Optional)'}
                </label>
                <input
                  type="text"
                  value={senderHandle}
                  onChange={(e) => setSenderHandle(e.target.value)}
                  placeholder="@handle or +91 98..."
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-purple-400"
                />
              </div>
            </div>

            {/* Message Input Box */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center justify-between">
                <span>{lang === 'ta' ? 'à®šà®¨à¯à®¤à¯‡à®•à®¤à¯à®¤à®¿à®±à¯à®•à¯à®°à®¿à®¯ à®šà¯†à®¯à¯à®¤à®¿ à®‰à®°à¯ˆ' : 'Message or Threat Text'}</span>
                <span className="text-[11px] font-normal text-slate-400">
                  {inputText.length} characters
                </span>
              </label>
             <div className="w-full">
  <label className="block text-xs font-bold text-slate-700 mb-2">
    {lang === 'ta' ? 'à®¸à¯à®•à®¿à®°à¯€à®©à¯à®·à®¾à®Ÿà¯ à®ªà®¤à®¿à®µà¯‡à®±à¯à®±à®µà¯à®®à¯' : 'Upload Message Screenshot'}
  </label>

  <label
  htmlFor="message-screenshot-upload"
  className="flex flex-col items-center justify-center w-full min-h-[220px] border-2 border-dashed border-purple-200 rounded-xl bg-purple-50/40 hover:bg-purple-50 cursor-pointer transition-colors"
>
    {screenshotPreview ? (
      <img
        src={screenshotPreview}
        alt="Screenshot preview"
        className="max-h-[200px] max-w-full rounded-lg object-contain"
      />
    ) : (
      <>
        <Send className="w-8 h-8 text-purple-500 mb-3" />
        <span className="text-sm font-semibold text-slate-700">
          {lang === 'ta'
            ? 'à®šà¯†à®¯à¯à®¤à®¿ à®¸à¯à®•à®¿à®°à¯€à®©à¯à®·à®¾à®Ÿà¯à®Ÿà¯ˆ à®ªà®¤à®¿à®µà¯‡à®±à¯à®±à®µà¯à®®à¯'
            : 'Upload a screenshot of the message'}
        </span>
        <span className="text-xs text-slate-400 mt-1">
          PNG, JPG, JPEG
        </span>
      </>
    )}

    <input
      id="message-screenshot-upload"
      type="file"
      accept="image/png,image/jpeg,image/jpg"
      className="hidden"
      onChange={(e) => {
        const file = e.target.files?.[0];

        if (!file) return;

        setScreenshotFile(file);
        setScreenshotPreview(URL.createObjectURL(file));
        setResult(null);
        setErrorMsg(null);
      }}
    />
  </label>

  {screenshotFile && (
    <p className="text-xs text-slate-500 mt-2">
      Selected: {screenshotFile.name}
    </p>
  )}
</div>
            </div>

            {errorMsg && (
              <div className="p-3 rounded-xl bg-rose-50 text-rose-700 text-xs border border-rose-200">
                {errorMsg}
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
              <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 text-purple-600" />
                <span>
                  {lang === 'ta' ? 'à®°à®•à®šà®¿à®¯à®®à®¾à®©à®¤à¯ â€¢ à®Žà®™à¯à®•à¯à®®à¯ à®šà¯‡à®®à®¿à®•à¯à®•à®ªà¯à®ªà®Ÿà®¾à®¤à¯' : 'Encrypted Client-First Inspection'}
                </span>
              </div>

              <button
                onClick={() => handleRunAnalysis(inputText)}
                disabled={isAnalyzing || (!inputText.trim() && !screenshotFile)}
                className="px-5 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition-all disabled:opacity-50"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>{lang === 'ta' ? 'à®®à®¤à®¿à®ªà¯à®ªà¯€à®Ÿà¯ à®šà¯†à®¯à¯à®•à®¿à®±à®¤à¯...' : 'Evaluating Legal Statutes...'}</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>{lang === 'ta' ? 'à®…à®šà¯à®šà¯à®±à¯à®¤à¯à®¤à®²à¯ˆ à®†à®¯à¯à®µà¯ à®šà¯†à®¯à¯' : 'Scan Message for Threat'}</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Crucial Victim Safety Protocol Advice */}
          <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-4 text-xs text-amber-900 space-y-2">
            <div className="flex items-center gap-2 font-bold text-amber-950">
              <AlertOctagon className="w-4 h-4 text-amber-600 shrink-0" />
              <span>{lang === 'ta' ? 'à®ªà®¾à®¤à¯à®•à®¾à®ªà¯à®ªà¯ à®¨à¯†à®±à®¿à®®à¯à®±à¯ˆ (à®®à¯à®•à¯à®•à®¿à®¯à®®à®¾à®©à®¤à¯)' : 'Immediate Safety Guidance'}</span>
            </div>
            <ul className="list-disc pl-5 space-y-1 text-amber-800 leading-relaxed">
              <li>
                <strong>
                  {lang === 'ta' ? 'à®‰à®°à¯ˆà®¯à®¾à®Ÿà®²à¯ˆ à®¨à¯€à®•à¯à®•à®¾à®¤à¯€à®°à¯à®•à®³à¯:' : 'Do NOT delete the chat:'}{' '}
                </strong>
                {lang === 'ta'
                  ? 'à®•à®¾à®µà®²à¯à®¤à¯à®±à¯ˆ à®µà®¿à®šà®¾à®°à®£à¯ˆà®•à¯à®•à¯ à®¨à¯‡à®° à®®à¯à®¤à¯à®¤à®¿à®°à¯ˆà®¯à¯à®Ÿà®©à¯ à®•à¯‚à®Ÿà®¿à®¯ (Timestamps) à®…à®šà®²à¯ à®†à®¤à®¾à®°à®®à¯ à®®à®¿à®• à®…à®µà®šà®¿à®¯à®®à¯.'
                  : 'Original message timestamps and headers are vital forensic evidence for cyber police.'}
              </li>
              <li>
                <strong>
                  {lang === 'ta' ? 'à®¤à®¿à®°à¯ˆà®ªà¯à®ªà®¿à®Ÿà®¿à®ªà¯à®ªà¯ (Screenshot) à®Žà®Ÿà¯à®•à¯à®•à®µà¯à®®à¯:' : 'Take Full Screenshots:'}{' '}
                </strong>
                {lang === 'ta'
                  ? 'à®…à®©à¯à®ªà¯à®ªà®¿à®¯à®µà®°à®¿à®©à¯ à®šà¯à®¯à®µà®¿à®µà®°à®®à¯ à®®à®±à¯à®±à¯à®®à¯ à®¤à¯Šà®²à¯ˆà®ªà¯‡à®šà®¿ à®Žà®£à¯ à®¤à¯†à®³à®¿à®µà®¾à®• à®¤à¯†à®°à®¿à®¯à¯à®®à¯ à®µà®•à¯ˆà®¯à®¿à®²à¯ à®ªà®Ÿà®®à¯à®ªà®¿à®Ÿà®¿à®•à¯à®•à®µà¯à®®à¯.'
                  : 'Capture the sender handle, phone number, profile photo, and full screen.'}
              </li>
              <li>
                <strong>{lang === 'ta' ? 'à®ªà®£à®®à¯ à®•à¯Šà®Ÿà¯à®•à¯à®•à®¾à®¤à¯€à®°à¯à®•à®³à¯:' : 'Never Pay Blackmailers:'} </strong>
                {lang === 'ta'
                  ? 'à®ªà®£à®®à¯ à®šà¯†à®²à¯à®¤à¯à®¤à¯à®µà®¤à¯ à®®à®¿à®°à®Ÿà¯à®Ÿà®²à¯ˆ à®…à®¤à®¿à®•à®ªà¯à®ªà®Ÿà¯à®¤à¯à®¤à¯à®®à¯‡ à®¤à®µà®¿à®° à®¨à®¿à®±à¯à®¤à¯à®¤à®¾à®¤à¯. à®‰à®Ÿà®©à®Ÿà®¿à®¯à®¾à®• à®ªà¯à®•à®¾à®°à®³à®¿à®•à¯à®•à®µà¯à®®à¯.'
                  : 'Extortionists will demand more money if paid. Report to Helpline 1930 immediately.'}
              </li>
            </ul>
          </div>
        </div>

        {/* Right: Results & Statute Mapping (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          {result ? (
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-5">
              {/* Verdict Header */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  {lang === 'ta' ? 'à®šà®Ÿà¯à®Ÿ à®°à¯€à®¤à®¿à®¯à®¾à®© à®®à®¤à®¿à®ªà¯à®ªà¯€à®Ÿà¯' : 'Threat Assessment'}
                </span>
                <span
                  className={`text-xs font-bold px-2.5 py-1 rounded-full ${
                    result.riskLevel === 'high'
                      ? 'bg-rose-100 text-rose-800 border border-rose-200'
                      : result.riskLevel === 'medium'
                      ? 'bg-amber-100 text-amber-800 border border-amber-200'
                      : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                  }`}
                >
                  {result.riskLevel === 'high'
                    ? (lang === 'ta' ? 'à®…à®¤à®¿à®• à®…à®šà¯à®šà¯à®±à¯à®¤à¯à®¤à®²à¯ (à®•à®¿à®°à®¿à®®à®¿à®©à®²à¯ à®•à¯à®±à¯à®±à®®à¯)' : 'HIGH SEVERITY (Actionable)')
                    : result.riskLevel === 'medium'
                    ? (lang === 'ta' ? 'à®¨à®Ÿà¯à®¤à¯à®¤à®° à®†à®ªà®¤à¯à®¤à¯ (à®ªà®¿à®©à¯à®¤à¯Šà®Ÿà®°à¯à®¤à®²à¯)' : 'MEDIUM RISK (Stalking)')
                    : (lang === 'ta' ? 'à®•à¯à®±à¯ˆà®¨à¯à®¤ à®†à®ªà®¤à¯à®¤à¯ (à®ªà®¾à®¤à¯à®•à®¾à®ªà¯à®ªà®¾à®©à®¤à¯)' : 'LOW RISK (Safe)')}
                </span>
              </div>

              {/* Threat Gauge */}
              <div className="flex items-center gap-4 bg-slate-50 p-4 rounded-xl border border-slate-100">
                <div className="relative w-20 h-20 shrink-0 flex items-center justify-center">
                  <svg className="w-20 h-20 transform -rotate-90" viewBox="0 0 36 36">
                    <path
                      className="text-slate-200"
                      strokeWidth="3.5"
                      stroke="currentColor"
                      fill="none"
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    />
                    <path
                      className={
                        result.riskLevel === 'high'
                          ? 'text-rose-500'
                          : result.riskLevel === 'medium'
                          ? 'text-amber-500'
                          : 'text-emerald-500'
                      }
                      strokeDasharray={`${result.riskScore}, 100`}
                      strokeWidth="3.5"
                      strokeLinecap="round"
                      stroke="currentColor"
                      fill="none"
                      d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-xl font-black text-slate-900">{result.riskScore}%</span>
                    <span className="text-[9px] font-semibold text-slate-500 uppercase">
                      {lang === 'ta' ? 'à®¤à¯€à®µà®¿à®°à®®à¯' : 'Severity'}
                    </span>
                  </div>
                </div>

                <div>
                  <h4 className="font-bold text-slate-900 text-sm">{result.summaryTitle}</h4>
                  <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                    {result.summaryDesc}
                  </p>
                </div>
              </div>

              {/* Detected violations / reasons */}
              <div className="space-y-2">
                <h5 className="text-xs font-bold text-slate-700 uppercase tracking-wide">
                  {lang === 'ta' ? 'à®•à®£à¯à®Ÿà®±à®¿à®¯à®ªà¯à®ªà®Ÿà¯à®Ÿ à®•à®¾à®°à®£à®™à¯à®•à®³à¯' : 'Evaluation Factors'}
                </h5>
                <ul className="space-y-1.5">
                  {result.reasons.map((r, i) => (
                    <li
                      key={i}
                      className="text-xs text-slate-700 bg-slate-50 p-2.5 rounded-lg border border-slate-100 flex items-start gap-2"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-rose-600 mt-1.5 shrink-0" />
                      <span>{r}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Applicable Indian Statutes Box */}
              <div className="bg-purple-50/70 border border-purple-200 rounded-xl p-3.5 space-y-2 text-xs">
                <div className="flex items-center gap-2 font-bold text-purple-900">
                  <Scale className="w-4 h-4 text-purple-700" />
                  <span>
                    {lang === 'ta'
                      ? 'à®ªà¯Šà®°à¯à®¨à¯à®¤à®•à¯à®•à¯‚à®Ÿà®¿à®¯ à®‡à®¨à¯à®¤à®¿à®¯ à®šà®Ÿà¯à®Ÿà®ªà¯ à®ªà®¿à®°à®¿à®µà¯à®•à®³à¯'
                      : 'Applicable Indian Legal Provisions'}
                  </span>
                </div>
                <div className="space-y-1.5 text-[11px] text-purple-800">
                  {result.riskLevel === 'high' ? (
                    <>
                      <div>
                        <strong>IT Act 66E / 67A:</strong>{' '}
                        {lang === 'ta'
                          ? 'à®†à®ªà®¾à®š à®…à®²à¯à®²à®¤à¯ à®®à®¾à®°à¯à®ªà®¿à®™à¯ à®…à®šà¯à®šà¯à®±à¯à®¤à¯à®¤à®²à¯ (5 à®†à®£à¯à®Ÿà¯à®•à®³à¯ à®µà®°à¯ˆ à®šà®¿à®±à¯ˆ)'
                          : 'Publishing / threatening morphed explicit content (up to 5 yrs prison)'}
                      </div>
                      <div>
                        <strong>BNS 351 (IPC 506):</strong>{' '}
                        {lang === 'ta'
                          ? 'à®•à¯à®±à¯à®±à®µà®¿à®¯à®²à¯ à®®à®¿à®°à®Ÿà¯à®Ÿà®²à¯ à®®à®±à¯à®±à¯à®®à¯ à®®à®¿à®°à®Ÿà¯à®Ÿà®¿ à®ªà®£à®®à¯ à®ªà®±à®¿à®¤à¯à®¤à®²à¯'
                          : 'Criminal intimidation and extortion'}
                      </div>
                    </>
                  ) : (
                    <div>
                      <strong>BNS 78 (IPC 354D):</strong>{' '}
                      {lang === 'ta'
                        ? 'à®ªà¯†à®£à¯à®•à®³à¯ˆ à®®à®¿à®©à¯à®©à®£à¯ à®®à¯à®±à¯ˆà®¯à®¿à®²à¯ à®ªà®¿à®©à¯à®¤à¯Šà®Ÿà®°à¯à®¨à¯à®¤à¯ à®¤à¯à®©à¯à®ªà¯à®±à¯à®¤à¯à®¤à¯à®¤à®²à¯'
                        : 'Cyber stalking and electronic harassment'}
                    </div>
                  )}
                </div>
              </div>

              {/* Actions */}
              <div className="pt-2 space-y-2">
                {!isAddedToVault ? (
                  <button
                    onClick={handleSaveToVault}
                    className="w-full py-2.5 px-4 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-colors"
                  >
                    <BookmarkPlus className="w-4 h-4" />
                    <span>
                      {lang === 'ta'
                        ? 'à®†à®¤à®¾à®° à®ªà¯†à®Ÿà¯à®Ÿà®•à®¤à¯à®¤à®¿à®²à¯ à®šà¯‡à®°à¯à®•à¯à®•à®µà¯à®®à¯'
                        : 'Save to Evidence Vault (for FIR)'}
                    </span>
                  </button>
                ) : (
                  <div className="flex items-center justify-between p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 font-semibold">
                    <div className="flex items-center gap-2">
                      <FileCheck className="w-4 h-4 text-emerald-600" />
                      <span>{lang === 'ta' ? 'à®ªà¯†à®Ÿà¯à®Ÿà®•à®¤à¯à®¤à®¿à®²à¯ à®šà¯‡à®°à¯à®•à¯à®•à®ªà¯à®ªà®Ÿà¯à®Ÿà®¤à¯!' : 'Added to Evidence Vault!'}</span>
                    </div>
                    <button
                      onClick={onNavigateToVault}
                      className="text-purple-700 hover:text-purple-900 underline text-xs font-bold"
                    >
                      {lang === 'ta' ? 'à®ªà¯†à®Ÿà¯à®Ÿà®•à®¤à¯à®¤à¯ˆà®ªà¯ à®ªà®¾à®°à¯' : 'View Vault'}
                    </button>
                  </div>
                )}

                <button
                  onClick={handleCopyLegalAdvice}
                  className="w-full py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span>{lang === 'ta' ? 'à®¨à®•à®²à¯†à®Ÿà¯à®•à¯à®•à®ªà¯à®ªà®Ÿà¯à®Ÿà®¤à¯' : 'Copied to Clipboard'}</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-slate-500" />
                      <span>{lang === 'ta' ? 'à®†à®¯à¯à®µà¯ à®šà¯à®°à¯à®•à¯à®•à®¤à¯à®¤à¯ˆ à®¨à®•à®²à¯†à®Ÿà¯' : 'Copy Evidence Summary'}</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs text-center space-y-4 flex flex-col items-center justify-center min-h-[320px]">
              <div className="w-12 h-12 rounded-2xl bg-rose-50 border border-rose-100 flex items-center justify-center text-rose-600">
                <MessageSquareWarning className="w-6 h-6" />
              </div>
              <div className="max-w-xs">
                <h4 className="font-bold text-slate-800 text-sm">
                  {lang === 'ta' ? 'à®šà¯†à®¯à¯à®¤à®¿ à®†à®¯à¯à®µà¯ à®®à¯à®Ÿà®¿à®µà¯' : 'Awaiting Message Text'}
                </h4>
                <p className="text-xs text-slate-500 mt-1">
                  {lang === 'ta'
                    ? 'à®‡à®Ÿà®¤à¯à®ªà¯à®±à®¤à¯à®¤à®¿à®²à¯ à®šà¯†à®¯à¯à®¤à®¿à®¯à¯ˆ à®’à®Ÿà¯à®Ÿà®¿ à®…à®²à¯à®²à®¤à¯ à®®à®¾à®¤à®¿à®°à®¿ à®ªà¯Šà®¤à¯à®¤à®¾à®©à¯ˆ à®…à®´à¯à®¤à¯à®¤à®¿ à®šà®Ÿà¯à®Ÿ à®®à®¤à®¿à®ªà¯à®ªà¯€à®Ÿà¯à®Ÿà¯ˆà®ªà¯ à®ªà¯†à®±à¯à®™à¯à®•à®³à¯.'
                    : 'Paste a message on the left or click a quick test case to evaluate threat level and legal remedies.'}
                </p>
              </div>

              <div className="w-full border-t border-slate-100 pt-4 text-left space-y-2">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                  {lang === 'ta' ? 'à®ªà®¾à®¤à¯à®•à®¾à®•à¯à®•à®ªà¯à®ªà®Ÿà¯à®®à¯ à®šà®Ÿà¯à®Ÿà®ªà¯ à®ªà®¿à®°à®¿à®µà¯à®•à®³à¯' : 'Key Protected Statutory Sections'}
                </span>
                <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-600">
                  <div className="bg-slate-50 p-2 rounded-lg">âœ“ IT Act 66E (Privacy)</div>
                  <div className="bg-slate-50 p-2 rounded-lg">âœ“ IT Act 67A (Morphing)</div>
                  <div className="bg-slate-50 p-2 rounded-lg">âœ“ BNS 78 (Stalking)</div>
                  <div className="bg-slate-50 p-2 rounded-lg">âœ“ BNS 351 (Extortion)</div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};


