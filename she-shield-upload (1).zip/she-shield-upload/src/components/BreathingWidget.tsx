import React, { useState, useEffect } from 'react';
import { Wind, X, Heart } from 'lucide-react';
import { Language } from '../types';

interface BreathingWidgetProps {
  lang: Language;
  onClose: () => void;
}

export const BreathingWidget: React.FC<BreathingWidgetProps> = ({ lang, onClose }) => {
  const [phase, setPhase] = useState<'Inhale' | 'Hold' | 'Exhale'>('Inhale');
  const [countdown, setCountdown] = useState<number>(4);

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          if (phase === 'Inhale') {
            setPhase('Hold');
            return 7;
          } else if (phase === 'Hold') {
            setPhase('Exhale');
            return 8;
          } else {
            setPhase('Inhale');
            return 4;
          }
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [phase]);

  const getPhaseText = () => {
    if (lang === 'ta') {
      if (phase === 'Inhale') return 'மூச்சை மெதுவாக உள்ளிழுங்கள்...';
      if (phase === 'Hold') return 'மூச்சை பிடித்து வையுங்கள்...';
      return 'மெதுவாக மூச்சை வெளியே விடுங்கள்...';
    }
    if (phase === 'Inhale') return 'Breathe in gently...';
    if (phase === 'Hold') return 'Hold your breath...';
    return 'Slowly exhale and release stress...';
  };

  return (
    <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-purple-50 border-b border-emerald-200 px-4 py-3 relative transition-all duration-500">
      <div className="max-w-4xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-slate-700">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600">
            <Heart className="w-4 h-4 text-emerald-500 animate-pulse" />
          </div>
          <div>
            <h4 className="font-semibold text-sm text-emerald-900">
              {lang === 'ta' ? 'நீங்கள் பாதுகாப்பாக இருக்கிறீர்கள்' : 'You are in a safe space'}
            </h4>
            <p className="text-xs text-slate-600">
              {lang === 'ta'
                ? 'பதற்றப்படாதீர்கள். நீங்கள் தனியாக இல்லை, சட்டமும் தொழில்நுட்பமும் உங்கள் பக்கம் உள்ளது.'
                : 'Take a deep breath. You are not alone, and help is available.'}
            </p>
          </div>
        </div>

        {/* Breathing Animation Circle */}
        <div className="flex items-center gap-3 bg-white/80 backdrop-blur-sm px-4 py-1.5 rounded-full border border-emerald-200 shadow-xs">
          <div
            className={`w-6 h-6 rounded-full bg-emerald-500 flex items-center justify-center text-white text-[10px] font-bold transition-transform duration-1000 ${
              phase === 'Inhale' ? 'scale-125 bg-emerald-600' : phase === 'Hold' ? 'scale-110 bg-teal-500' : 'scale-90 bg-slate-400'
            }`}
          >
            {countdown}
          </div>
          <span className="text-xs font-semibold text-emerald-950">
            {getPhaseText()}
          </span>
        </div>

        <button
          onClick={onClose}
          className="text-slate-400 hover:text-slate-600 p-1 rounded-full hover:bg-slate-200/50"
          title="Close calming guide"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
