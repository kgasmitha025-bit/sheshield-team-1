import React, { useState } from 'react';
import {
  PhoneCall,
  ExternalLink,
  Shield,
  HelpCircle,
  AlertTriangle,
  FileText,
  Lock,
  ChevronDown,
  ChevronUp,
  Globe2,
  CheckCircle,
} from 'lucide-react';
import { Language } from '../types';
import { HELPLINE_NUMBERS, INDIAN_LEGAL_STATUTES } from '../data/legalData';

interface HelplineGuideProps {
  lang: Language;
}

export const HelplineGuide: React.FC<HelplineGuideProps> = ({ lang }) => {
  const [activeTab, setActiveTab] = useState<'helplines' | 'portals' | 'laws'>('helplines');
  const [expandedFaq, setExpandedFaq] = useState<number | null>(0);

  const reportingSteps = [
    {
      titleEn: '1. National Cyber Crime Reporting Portal (cybercrime.gov.in)',
      titleTa: '1. தேசிய சைபர் குற்ற அறிக்கை இணையதளம் (cybercrime.gov.in)',
      descEn:
        'The Government of India provides a dedicated, anonymous reporting pathway specifically for "Women & Child Related Crime". You can file complaints anonymously without revealing your identity to the public.',
      descTa:
        'இந்திய அரசு பெண்கள் மற்றும் குழந்தைகளுக்கான சிறப்பு ரகசிய புகார் பிரிவை உருவாக்கியுள்ளது. உங்கள் அடையாளத்தை வெளிப்படுத்தாமல் புகாரளிக்கலாம்.',
      actionLink: 'https://cybercrime.gov.in',
      actionTextEn: 'Visit cybercrime.gov.in',
      actionTextTa: 'இணையதளத்தை திறக்க',
    },
    {
      titleEn: '2. StopNCII.org (Prevent Morphed / Intimate Photo Spread)',
      titleTa: '2. StopNCII.org (படங்கள் பரவுவதைத் தடுத்தல்)',
      descEn:
        'StopNCII generates a unique cryptographic hash of your image directly on your device. The actual photo NEVER leaves your phone/computer. Tech platforms (Meta, Instagram, TikTok, OnlyFans) use this hash to automatically block anyone from uploading it.',
      descTa:
        'உங்கள் சாதனத்திலேயே ரகசிய ஹேஷிங் உருவாக்கி, அசல் புகைப்படத்தை எங்கும் பதிவேற்றாமல் இன்ஸ்டாகிராம் மற்றும் பேஸ்புக்கில் அது பரவாமல் தடுக்கிறது.',
      actionLink: 'https://stopncii.org',
      actionTextEn: 'Protect via StopNCII',
      actionTextTa: 'StopNCII தளத்திற்குச் செல்ல',
    },
    {
      titleEn: '3. Platform-Specific Emergency Takedown (24-Hour Mandate)',
      titleTa: '3. சமூக ஊடக உடனடி நீக்கம் (சட்டப்படி 24 மணி நேரத்திற்குள்)',
      descEn:
        'Under Rule 3(2)(b) of the IT Rules 2021, social media intermediaries (Instagram, WhatsApp, X, Google) are legally mandated to remove non-consensual sexually explicit or morphed content within 24 hours of reporting.',
      descTa:
        'இந்திய தகவல் தொழில்நுட்ப விதி 2021-ன் படி, புகார் அளிக்கப்பட்ட 24 மணி நேரத்திற்குள் அத்தகைய படங்களை நீக்க சமூக வலைதளங்கள் கடமைப்பட்டுள்ளன.',
      actionLink: 'https://instagram.com',
      actionTextEn: 'Report on Platform',
      actionTextTa: 'தளத்தில் புகாரளிக்க',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-5 md:p-6 border border-purple-100 shadow-xs">
        <div className="flex items-center gap-2 mb-1">
          <span className="w-2.5 h-2.5 rounded-full bg-indigo-600"></span>
          <span className="text-xs font-bold text-indigo-700 uppercase tracking-wider">
            {lang === 'ta' ? 'அவசர உதவி & சட்ட வழிகாட்டி' : 'Emergency Helplines & Legal Playbook'}
          </span>
        </div>
        <h2 className="text-xl md:text-2xl font-bold text-slate-900 tracking-tight">
          {lang === 'ta' ? 'உடனடி உதவி மற்றும் சட்டப்பூர்வ உரிமைகள்' : 'Instant Helplines & Step-by-Step Reporting'}
        </h2>
        <p className="text-sm text-slate-600 mt-1 max-w-2xl">
          {lang === 'ta'
            ? 'இந்திய அரசின் சைபர் குற்ற உதவி எண்கள், சமூக வலைதளங்களில் உள்ளடக்கங்களை நீக்குவதற்கான வழிகாட்டுதல்கள் மற்றும் சட்டப் பாதுகாப்பு விவரங்கள்.'
            : 'Immediate emergency contacts, anonymous government portals, platform takedown protocols under IT Rules 2021, and penal code protections.'}
        </p>

        {/* Sub-nav tabs */}
        <div className="mt-5 flex gap-2 border-b border-slate-100 pb-2">
          <button
            onClick={() => setActiveTab('helplines')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'helplines'
                ? 'bg-purple-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {lang === 'ta' ? 'அவசர உதவி எண்கள்' : 'Emergency Hotlines'}
          </button>
          <button
            onClick={() => setActiveTab('portals')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'portals'
                ? 'bg-purple-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {lang === 'ta' ? 'புகாரளிக்கும் முறை' : 'Reporting Steps'}
          </button>
          <button
            onClick={() => setActiveTab('laws')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'laws'
                ? 'bg-purple-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            {lang === 'ta' ? 'இந்திய சட்டப் பிரிவுகள்' : 'Indian Law Provisions'}
          </button>
        </div>
      </div>

      {/* Tab 1: Hotlines */}
      {activeTab === 'helplines' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {HELPLINE_NUMBERS.map((h, i) => (
            <div
              key={i}
              className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col justify-between space-y-4 hover:border-purple-200 transition-all"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
                    {h.number}
                  </span>
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 text-slate-700">
                    {h.badge}
                  </span>
                </div>
                <h4 className="font-bold text-slate-900 text-sm">
                  {lang === 'ta' ? h.titleTa : h.titleEn}
                </h4>
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  {lang === 'ta' ? h.descTa : h.descEn}
                </p>
              </div>

              <a
                href={h.dialLink}
                className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-colors"
              >
                <PhoneCall className="w-3.5 h-3.5 text-emerald-400" />
                <span>
                  {lang === 'ta' ? `${h.number} ஐ அழைக்கவும்` : `Call ${h.number} Now`}
                </span>
              </a>
            </div>
          ))}
        </div>
      )}

      {/* Tab 2: Reporting Steps */}
      {activeTab === 'portals' && (
        <div className="space-y-4">
          {reportingSteps.map((step, idx) => (
            <div
              key={idx}
              className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3"
            >
              <div className="flex items-start justify-between gap-4">
                <h4 className="text-sm font-bold text-slate-900">
                  {lang === 'ta' ? step.titleTa : step.titleEn}
                </h4>
                <a
                  href={step.actionLink}
                  target="_blank"
                  rel="noreferrer"
                  className="px-3 py-1.5 rounded-xl bg-purple-50 text-purple-700 hover:bg-purple-100 border border-purple-200 text-xs font-bold flex items-center gap-1.5 shrink-0 transition-colors"
                >
                  <span>{lang === 'ta' ? step.actionTextTa : step.actionTextEn}</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                {lang === 'ta' ? step.descTa : step.descEn}
              </p>
            </div>
          ))}

          {/* Social Media Takedown Playbook Box */}
          <div className="bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-200 rounded-2xl p-5 space-y-3">
            <h4 className="font-bold text-purple-950 text-sm flex items-center gap-2">
              <Shield className="w-4 h-4 text-purple-700" />
              <span>
                {lang === 'ta'
                  ? 'சமூக வலைதளங்களில் உள்ளடக்கங்களை நீக்கும் வழிகாட்டி'
                  : 'Mandatory 24-Hour Intermediary Takedown Rule'}
              </span>
            </h4>
            <p className="text-xs text-purple-900 leading-relaxed">
              {lang === 'ta'
                ? 'இந்திய தகவல் தொழில்நுட்ப விதிகள் 2021 பிரிவு 3(2)(b) படி, வாட்ஸ்அப், இன்ஸ்டாகிராம் போன்ற நிறுவனங்கள் பாலியல் அச்சுறுத்தல் அல்லது மார்பிங் புகைப்படங்களை புகார் வந்த 24 மணி நேரத்திற்குள் கட்டாயம் நீக்க வேண்டும்.'
                : 'Under the Information Technology (Intermediary Guidelines) Rules 2021 Rule 3(2)(b), platforms like Instagram, WhatsApp, and Google MUST take down non-consensual morphed or explicit imagery within 24 hours of receiving a complaint.'}
            </p>
          </div>
        </div>
      )}

      {/* Tab 3: Legal Provisions */}
      {activeTab === 'laws' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {INDIAN_LEGAL_STATUTES.map((law, idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3 hover:border-purple-200 transition-colors"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="px-2.5 py-1 bg-purple-100 text-purple-800 rounded-lg text-xs font-extrabold tracking-wide">
                    {law.code}
                  </span>
                  <span className="text-[11px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
                    {law.badge}
                  </span>
                </div>
                <div>
                  <h4 className="font-bold text-slate-900 text-sm">
                    {lang === 'ta' ? law.titleTa : law.titleEn}
                  </h4>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    {lang === 'ta' ? law.descriptionTa : law.descriptionEn}
                  </p>
                </div>
                <div className="pt-2 border-t border-slate-100 text-[11px] text-rose-700 bg-rose-50/70 p-2.5 rounded-xl border border-rose-100">
                  <strong>{lang === 'ta' ? 'தண்டனை விவரம்:' : 'Punishment:'} </strong>
                  {lang === 'ta' ? law.penaltyTa : law.penaltyEn}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
