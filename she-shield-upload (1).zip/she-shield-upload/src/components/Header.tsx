import React, { useState } from 'react';
import { Shield, ShieldAlert, PhoneCall, ExternalLink, Wind, Globe2, UserCircle } from 'lucide-react';
import { Language } from '../types';

interface HeaderSession {
  user?: {
    id?: string;
    email?: string;
    created_at?: string;
  };
}

interface HeaderProps {
  lang: Language;
  onLanguageChange: (lang: Language) => void;
  onOpenPanicExit: () => void;
  onToggleBreathing: () => void;
  isBreathingActive: boolean;
  session?: HeaderSession | null;
  onOpenAuth?: () => void;
  onSignOut?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  lang,
  onLanguageChange,
  onOpenPanicExit,
  onToggleBreathing,
  isBreathingActive,
  session,
  onOpenAuth,
  onSignOut,
}) => {
  const [showAccount, setShowAccount] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-purple-100 shadow-xs">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between gap-2">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-purple-500 flex items-center justify-center text-white shadow-md shadow-purple-200">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-bold text-lg md:text-xl text-slate-900 tracking-tight leading-none">
                SheShield
              </h1>
              <span className="hidden sm:inline-flex px-2 py-0.5 text-[11px] font-semibold tracking-wide uppercase bg-purple-100 text-purple-700 rounded-full">
                AI Forensic Shield
              </span>
            </div>
            <p className="text-xs text-slate-500 hidden sm:block">
              {lang === 'ta'
                ? 'டீப்ஃபேக் & இணைய அச்சுறுத்தல் பாதுகாப்பு தளம்'
                : 'Deepfake & Online Harassment Defense'}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Calming Breathing Mode */}
          <button
            onClick={onToggleBreathing}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all ${
              isBreathingActive
                ? 'bg-emerald-100 text-emerald-800 ring-2 ring-emerald-300'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
            title={lang === 'ta' ? 'அமைதிப்படுத்தும் சுவாசப் பயிற்சி' : 'Calm breathing exercise'}
          >
            <Wind className={`w-3.5 h-3.5 ${isBreathingActive ? 'animate-pulse text-emerald-600' : ''}`} />
            <span className="hidden md:inline">
              {lang === 'ta' ? 'அமைதி சுவாசம்' : 'Calm Mind'}
            </span>
          </button>

          {/* Language Selector */}
          <div className="flex items-center bg-slate-100 rounded-lg p-0.5 border border-slate-200">
            <button
              onClick={() => onLanguageChange('en')}
              className={`px-2 py-1 text-xs font-semibold rounded-md transition-all ${
                lang === 'en'
                  ? 'bg-white text-purple-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              EN
            </button>
            <button
              onClick={() => onLanguageChange('ta')}
              className={`px-2 py-1 text-xs font-semibold rounded-md transition-all ${
                lang === 'ta'
                  ? 'bg-white text-purple-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              தமிழ்
            </button>
          </div>

          {/* Account */}
          {session ? (
            <div className="relative">
              <button
                onClick={() => setShowAccount(!showAccount)}
                className="flex items-center gap-1.5 bg-purple-50 border border-purple-200 text-purple-700 px-2.5 py-1.5 rounded-lg text-xs font-semibold hover:bg-purple-100 transition-colors"
                title="Account"
              >
                <UserCircle className="w-3.5 h-3.5" />
                <span className="max-w-[110px] truncate">
                  {session.user?.email || 'Account'}
                </span>
              </button>

              {showAccount && (
                <div className="absolute right-0 top-full mt-2 w-72 bg-white border border-purple-100 rounded-xl shadow-xl p-4 z-[100]">
                  <div className="flex items-center gap-2 mb-3">
                    <UserCircle className="w-5 h-5 text-purple-600" />
                    <div>
                      <p className="text-sm font-bold text-slate-900">My Account</p>
                      <p className="text-[11px] text-green-600">Signed in</p>
                    </div>
                  </div>

                  <div className="space-y-2 text-xs">
                    <div>
                      <p className="font-semibold text-slate-500">Email</p>
                      <p className="text-slate-800 break-all">{session.user?.email || 'Not available'}</p>
                    </div>

                    <div>
                      <p className="font-semibold text-slate-500">User ID</p>
                      <p className="text-slate-700 break-all">{session.user?.id || 'Not available'}</p>
                    </div>

                    <div>
                      <p className="font-semibold text-slate-500">Account Created</p>
                      <p className="text-slate-700">
                        {session.user?.created_at
                          ? new Date(session.user.created_at).toLocaleDateString()
                          : 'Not available'}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={onSignOut}
                    className="w-full mt-4 bg-rose-50 text-rose-700 border border-rose-200 px-3 py-2 rounded-lg text-xs font-semibold hover:bg-rose-100"
                  >
                    Sign Out
                  </button>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="flex items-center gap-1.5 bg-purple-600 text-white px-3 py-2 rounded-lg text-xs font-semibold hover:bg-purple-700 transition-colors z-50"
              title="Sign in"
            >
              <UserCircle className="w-3.5 h-3.5" />
              <span>Sign In</span>
            </button>
          )}

          {/* Quick Helpline Pill */}
          <a
            href="tel:1930"
            className="hidden sm:flex items-center gap-1.5 bg-rose-50 border border-rose-200 text-rose-700 px-2.5 py-1.5 rounded-lg text-xs font-semibold hover:bg-rose-100 transition-colors"
            title="National Cyber Crime Helpline"
          >
            <PhoneCall className="w-3.5 h-3.5 text-rose-600 animate-bounce" />
            <span>1930</span>
          </a>

          {/* Panic / Quick Exit Button */}
          <button
            onClick={onOpenPanicExit}
            className="bg-slate-800 hover:bg-slate-900 text-white px-2.5 md:px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
            title={lang === 'ta' ? 'உடனடி வெளியேறு (பாதுகாப்பிற்கு)' : 'Instant exit to neutral screen'}
          >
            <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
            <span>{lang === 'ta' ? 'வெளியேறு' : 'Quick Exit'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
