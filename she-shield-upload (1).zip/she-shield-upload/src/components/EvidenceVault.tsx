import React, { useState } from 'react';
import {
  FileText,
  Download,
  Trash2,
  Shield,
  Clock,
  ExternalLink,
  PlusCircle,
  AlertTriangle,
  FolderOpen,
  CheckCircle2,
  Lock,
  FileCheck2,
} from 'lucide-react';
import { jsPDF } from 'jspdf';
import { EvidenceItem, Language } from '../types';

interface EvidenceVaultProps {
  evidence: EvidenceItem[];
  onRemoveEvidence: (id: string) => void;
  onClearAll: () => void;
  lang: Language;
  onNavigateToScan: () => void;
}

export const EvidenceVault: React.FC<EvidenceVaultProps> = ({
  evidence,
  onRemoveEvidence,
  onClearAll,
  lang,
  onNavigateToScan,
}) => {
  const [complainantName, setComplainantName] = useState<string>('');
  const [incidentDate, setIncidentDate] = useState<string>(
    new Date().toISOString().split('T')[0]
  );
  const [policeStation, setPoliceStation] = useState<string>('cybercrime.gov.in / National Portal');
  const [additionalNotes, setAdditionalNotes] = useState<string>('');
  const [isGeneratingPdf, setIsGeneratingPdf] = useState<boolean>(false);

  const downloadEvidencePDF = async (item: EvidenceItem) => {
  try {
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(16);
    doc.text('SheShield - Individual Evidence Report', 14, 20);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.text(`Evidence: ${item.title}`, 14, 30);
    doc.text(`Type: ${item.type.toUpperCase()}`, 14, 36);
    doc.text(`Platform: ${item.platform || 'Direct Upload'}`, 14, 42);
    doc.text(`Timestamp: ${new Date(item.timestamp).toLocaleString()}`, 14, 48);
    doc.text(`AI Risk Score: ${item.riskScore}% (${item.riskLevel.toUpperCase()})`, 14, 54);

    let y = 64;

    if (item.type === 'image' && item.previewUrl) {
      try {
        doc.addImage(item.previewUrl, 'JPEG', 14, y, 100, 75);
        y += 85;
      } catch (imageError) {
        console.warn('Could not add evidence image:', imageError);
      }
    }

    doc.setFont('helvetica', 'bold');
    doc.text('Summary', 14, y);
    y += 6;

    doc.setFont('helvetica', 'normal');
    const summaryLines = doc.splitTextToSize(item.content || 'No summary available.', 180);
    doc.text(summaryLines, 14, y);
    y += summaryLines.length * 5 + 8;

    if (item.reasons && item.reasons.length > 0) {
      doc.setFont('helvetica', 'bold');
      doc.text('Findings', 14, y);
      y += 6;

      doc.setFont('helvetica', 'normal');
      item.reasons.forEach((reason) => {
        const lines = doc.splitTextToSize(`� ${reason}`, 180);
        doc.text(lines, 14, y);
        y += lines.length * 5 + 2;
      });
    }

    doc.save(`SheShield-Evidence-${item.id}.pdf`);
  } catch (error) {
    console.error('Individual evidence PDF failed:', error);
  }
};

const generateComplaintPDF = () => {
    setIsGeneratingPdf(true);
    try {
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const primaryColor = '#4f46e5';
      const textColor = '#1e293b';
      const accentRose = '#e11d48';

      let y = 18;

      // Header Banner
      doc.setFillColor(79, 70, 229);
      doc.rect(14, y, 182, 18, 'F');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(14);
      doc.setTextColor('#ffffff');
      doc.text('SHESHIELD - CYBER CRIME COMPLAINT DOSSIER', 20, y + 11);

      y += 24;

      // Subheading & Reference
      doc.setFontSize(9);
      doc.setTextColor('#64748b');
      doc.text(
        `Generated: ${new Date().toLocaleString()} | Ref ID: SHIELD-${Date.now().toString().slice(-6)}`,
        14,
        y
      );
      doc.text(
        'Format compliant with Section 63 BSA / 65B Indian Evidence Act for Electronic Records',
        14,
        y + 5
      );

      y += 12;

      // Addressed To
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(textColor);
      doc.text('TO:', 14, y);
      doc.setFont('helvetica', 'normal');
      doc.text(
        `The Station House Officer / Cyber Crime Police Officer\nJurisdiction / Portal: ${policeStation}`,
        14,
        y + 5
      );

      y += 16;

      // Complainant & Incident Particulars
      doc.setFont('helvetica', 'bold');
      doc.text('INCIDENT & COMPLAINANT PARTICULARS:', 14, y);
      y += 6;

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.text(`Complainant Name / Pseudonym: ${complainantName || 'Anonymous / Protected Victim'}`, 14, y);
      doc.text(`Incident Date / Timeline: ${incidentDate}`, 110, y);
      y += 5;
      doc.text(
        `Primary Nature: Non-Consensual Morphed Media / AI Deepfake Extortion & Cyber Harassment`,
        14,
        y
      );
      y += 5;
      doc.text(
        `Reporting Category: National Cyber Crime Portal (cybercrime.gov.in) - Crime Against Women`,
        14,
        y
      );

      y += 10;

      // Applicable Statutory Violations
      doc.setFillColor(243, 244, 246);
      doc.rect(14, y, 182, 18, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(accentRose);
      doc.text('APPLICABLE STATUTORY PENAL PROVISIONS:', 18, y + 5);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(textColor);
      doc.text(
        '• Information Technology Act, 2000: Section 66E (Bodily Privacy Violation), Section 67A (Sexually Explicit Content)',
        18,
        y + 10
      );
      doc.text(
        '• Bharatiya Nyaya Sanhita (BNS) 2023: Section 78 (Stalking), Section 351 (Criminal Intimidation), Section 79 (Insulting Modesty)',
        18,
        y + 14
      );

      y += 24;

      // Forensic Evidence Table
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.setTextColor(primaryColor);
      doc.text(`INDEXED ELECTRONIC FORENSIC EVIDENCE (${evidence.length} ITEMS):`, 14, y);
      y += 6;

      evidence.forEach((item, index) => {
        if (y > 255) {
          doc.addPage();
          y = 20;
        }

        doc.setFillColor(248, 250, 252);
        doc.rect(14, y, 182, 28, 'F');
        doc.setDrawColor(226, 232, 240);
        doc.rect(14, y, 182, 28, 'S');

        doc.setFont('helvetica', 'bold');
        doc.setFontSize(9);
        doc.setTextColor(textColor);
        doc.text(
          `#${index + 1}. [${item.type.toUpperCase()}] ${item.title} (${item.platform || 'Direct Upload'})`,
          18,
          y + 6
        );

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8);
        doc.setTextColor('#475569');
        doc.text(
          `Timestamp: ${new Date(item.timestamp).toLocaleString()} | AI Risk Score: ${item.riskScore}% (${item.riskLevel.toUpperCase()})`,
          18,
          y + 11
        );

        // Truncated content preview
        const previewStr = item.content.length > 110 ? item.content.substring(0, 110) + '...' : item.content;
        doc.text(`Summary: "${previewStr}"`, 18, y + 16);

        // Key reasons
        if (item.reasons && item.reasons.length > 0) {
          doc.setTextColor(accentRose);
          doc.text(`Findings: ${item.reasons[0].substring(0, 100)}`, 18, y + 21);
        }

        doc.setTextColor(textColor);
        y += 32;
      });

      if (y > 240) {
        doc.addPage();
        y = 20;
      }

      // Additional Notes
      if (additionalNotes) {
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(9);
        doc.text('VICTIM STATEMENT / IMPACT SUMMARY:', 14, y);
        y += 5;
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8.5);
        const splitNotes = doc.splitTextToSize(additionalNotes, 180);
        doc.text(splitNotes, 14, y);
        y += splitNotes.length * 4.5 + 4;
      }

      // Declaration & Electronic Sign-off
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.text('ELECTRONIC RECORD INTEGRITY DECLARATION:', 14, y);
      y += 4;
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor('#64748b');
      doc.text(
        'I hereby declare that the electronic evidence provided above consists of authentic communications and unaltered media files received or inspected by the SheShield Forensic engine. This document is submitted to initiate lawful investigation and takedown proceedings under the Information Technology (Intermediary Guidelines and Digital Media Ethics Code) Rules, 2021.',
        14,
        y,
        { maxWidth: 182 }
      );

      // Save PDF
      doc.save(`SheShield_Cyber_Crime_Complaint_${Date.now().toString().slice(-6)}.pdf`);
    } catch (err) {
      console.error('Error generating PDF:', err);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl p-5 md:p-6 border border-purple-100 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
            <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider">
              {lang === 'ta' ? 'பாதுகாக்கப்பட்ட ஆதார பெட்டகம்' : 'Tamper-Evident Evidence Vault'}
            </span>
          </div>
          <h2 className="text-xl md:text-2xl font-bold text-slate-900 tracking-tight">
            {lang === 'ta' ? 'சைபர் காவல் புகார் ஆவணம் தயாரித்தல்' : 'Official Police FIR & Portal Dossier'}
          </h2>
          <p className="text-sm text-slate-600 mt-1 max-w-2xl">
            {lang === 'ta'
              ? 'ஆய்வு செய்யப்பட்ட டீப்ஃபேக் படங்கள் மற்றும் மிரட்டல் செய்திகளை முறைப்படுத்தப்பட்ட சட்டப்பூர்வ புகார் மனுவாக (PDF) பதிவிறக்கம் செய்து cybercrime.gov.in-ல் சமர்ப்பிக்கலாம்.'
              : 'Compile your scanned deepfakes, extortion texts, timestamps, and statutory citations into a structured cyber crime complaint ready for FIR registration.'}
          </p>
        </div>

        {evidence.length > 0 && (
          <button
            onClick={generateComplaintPDF}
            disabled={isGeneratingPdf}
            className="w-full sm:w-auto px-5 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-all shrink-0"
          >
            {isGeneratingPdf ? (
              <span>{lang === 'ta' ? 'தயாராகிறது...' : 'Generating PDF...'}</span>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>{lang === 'ta' ? 'புகார் மனுவை (PDF) பதிவிறக்கு' : 'Download FIR Dossier (PDF)'}</span>
              </>
            )}
          </button>
        )}
      </div>

      {evidence.length === 0 ? (
        <div className="bg-white rounded-2xl p-8 md:p-12 border border-slate-200 text-center flex flex-col items-center justify-center space-y-4 shadow-xs">
          <div className="w-16 h-16 rounded-2xl bg-purple-50 border border-purple-100 flex items-center justify-center text-purple-600">
            <FolderOpen className="w-8 h-8" />
          </div>
          <div className="max-w-md">
            <h3 className="text-lg font-bold text-slate-800">
              {lang === 'ta' ? 'ஆதார பெட்டகம் காலியாக உள்ளது' : 'Your Evidence Vault is Empty'}
            </h3>
            <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
              {lang === 'ta'
                ? 'டீப்ஃபேக் ஸ்கேனர் அல்லது மெசேஜ் ஸ்கேனரில் ஆய்வு செய்த பிறகு "ஆதார பெட்டகத்தில் சேர்க்கவும்" என்பதை கிளிக் செய்யவும்.'
                : 'Scan suspect photos or extortion messages first, then click "Save to Evidence Vault" to compile your case dossier.'}
            </p>
          </div>
          <button
            onClick={onNavigateToScan}
            className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition-colors"
          >
            {lang === 'ta' ? 'ஆய்வைத் தொடங்கவும்' : 'Go to Scanners'}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Evidence List (7 cols) */}
          <div className="lg:col-span-7 space-y-3">
            <div className="flex items-center justify-between px-1">
              <span className="text-xs font-bold text-slate-700">
                {lang === 'ta' ? `சேமிக்கப்பட்ட ஆதாரங்கள் (${evidence.length})` : `Saved Evidence Records (${evidence.length})`}
              </span>
              <button
                onClick={onClearAll}
                className="text-xs text-rose-600 hover:text-rose-800 font-semibold flex items-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{lang === 'ta' ? 'அனைத்தையும் நீக்கு' : 'Clear All'}</span>
              </button>
            </div>

            {evidence.map((item) => (
              <div
                key={item.id}
                className="bg-white rounded-2xl p-4 border border-slate-200 shadow-xs space-y-3 hover:border-purple-200 transition-colors"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                        item.type === 'image'
                          ? 'bg-purple-100 text-purple-700'
                          : 'bg-indigo-100 text-indigo-700'
                      }`}
                    >
                      {item.type === 'image' ? (
                        <FileCheck2 className="w-4 h-4" />
                      ) : (
                        <FileText className="w-4 h-4" />
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-xs font-bold text-slate-900">{item.title}</h4>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            item.riskLevel === 'high'
                              ? 'bg-rose-100 text-rose-800'
                              : item.riskLevel === 'medium'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {item.riskScore}% {item.riskLevel.toUpperCase()}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                        <Clock className="w-3 h-3" />
                        <span>{new Date(item.timestamp).toLocaleString()}</span>
                        <span>•</span>
                        <span>{item.platform || 'Direct Upload'}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => onRemoveEvidence(item.id)}
                    className="text-slate-400 hover:text-rose-600 p-1 rounded-lg transition-colors"
                    title="Remove item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                {/* Preview snippet or thumbnail */}
                {item.type === 'image' && item.previewUrl && (
                  <div className="rounded-xl overflow-hidden bg-slate-900 max-h-32 flex items-center justify-center p-1">
                    <img
                      src={item.previewUrl}
                      alt={item.title}
                      className="max-h-28 w-auto object-contain rounded-lg"
                    />
                  </div>
                )}

                <p className="text-xs text-slate-700 bg-slate-50 p-2.5 rounded-xl border border-slate-100 leading-relaxed font-mono">
                  {item.content}
                </p>

                {item.reasons && item.reasons.length > 0 && (
                  <div className="text-[11px] text-slate-500 bg-purple-50/50 p-2 rounded-lg border border-purple-100">
                    <strong className="text-purple-900">
                      {lang === 'ta' ? 'தடையவியல் குறிப்பு:' : 'Forensic Observation:'}{' '}
                    </strong>
                    {item.reasons[0]}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Dossier Customization & Filing Form (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-4">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider border-b border-slate-100 pb-2">
                {lang === 'ta' ? 'புகார் மனு விவரங்கள்' : 'FIR / Complaint Particulars'}
              </h3>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'ta' ? 'புகார்தாரர் பெயர் / அடையாளம்' : 'Complainant Name (Can be Confidential)'}
                </label>
                <input
                  type="text"
                  value={complainantName}
                  onChange={(e) => setComplainantName(e.target.value)}
                  placeholder="Anonymous Victim / Priya S."
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-purple-400"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'ta' ? 'சம்பவ தேதி' : 'Incident Date'}
                </label>
                <input
                  type="date"
                  value={incidentDate}
                  onChange={(e) => setIncidentDate(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-purple-400"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'ta' ? 'சமர்ப்பிக்கப்படும் காவல் நிலையம் / இணையதளம்' : 'Target Portal / Police Station'}
                </label>
                <input
                  type="text"
                  value={policeStation}
                  onChange={(e) => setPoliceStation(e.target.value)}
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:ring-2 focus:ring-purple-400"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {lang === 'ta' ? 'பாதிப்பு விளக்கம் / கூடுதல் குறிப்புகள்' : 'Victim Narrative / Threat Context'}
                </label>
                <textarea
                  value={additionalNotes}
                  onChange={(e) => setAdditionalNotes(e.target.value)}
                  rows={4}
                  placeholder={
                    lang === 'ta'
                      ? 'எவ்வாறு இந்த அச்சுறுத்தல் தொடங்கியது என்பதை சுருக்கமாக விவரிக்கவும்...'
                      : 'Describe how the perpetrator contacted you, any extortion demands made, and distress caused...'
                  }
                  className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl p-3 text-slate-800 focus:outline-none focus:ring-2 focus:ring-purple-400"
                />
              </div>

              <div className="pt-2">
                <button
                  onClick={generateComplaintPDF}
                  disabled={isGeneratingPdf}
                  className="w-full py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-colors"
                >
                  <Download className="w-4 h-4" />
                  <span>{lang === 'ta' ? 'முழுமையான PDF அறிக்கையை பதிவிறக்கு' : 'Download Complete FIR PDF'}</span>
                </button>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-600 space-y-1">
                <div className="font-bold text-slate-800 flex items-center gap-1">
                  <Lock className="w-3 h-3 text-purple-600" />
                  <span>{lang === 'ta' ? 'சட்டப்பூர்வ பாதுகாப்பு குறிப்பு' : 'Legal Evidentiary Value'}</span>
                </div>
                <p>
                  {lang === 'ta'
                    ? 'இந்த PDF-ல் உள்ள நேர முத்திரைகள் மற்றும் தடையவியல் பகுப்பாய்வு பிரிவு 65B சான்றிதழுக்கு உட்பட்டது.'
                    : 'The generated PDF includes metadata hashes and forensic indicators suitable for formal filing under Section 65B of Indian Evidence Act.'}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};


